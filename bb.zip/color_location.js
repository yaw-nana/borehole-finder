var color_location = {
    "type": "FeatureCollection",
    "features": [{
            "type": "Feature",
            "properties": {
                "color": "Red"
            },
            "geometry": {
                "coordinates": [-1.4834121098343473, 6.317736103169381],
                "type": "Point"
            }
        }, {
            "type": "Feature",
            "properties": {
                "color": "Blue"
            },
            "geometry": {
                "coordinates": [-1.3927477816900478, 6.407063841085218],
                "type": "Point"
            }
        },
        {
            "type": "Feature",
            "properties": {
                "color": "knust"
            },
            "geometry": {
                "coordinates": [
                    [
                        [
                            -1.5662717953403842,
                            6.6700598198018355
                        ],
                        [
                            -1.5662613127562395,
                            6.669947153005737
                        ],
                        [
                            -1.5662525771102196,
                            6.669874270218585
                        ],
                        [
                            -1.5662543242392246,
                            6.669678180761181
                        ],
                        [
                            -1.5657459095802722,
                            6.669688592592422
                        ],
                        [
                            -1.565782599297819,
                            6.670065153687105
                        ],
                        [
                            -1.5662717953403842,
                            6.6700598198018355
                        ]
                    ]
                ],
                "type": "Polygon"
            }
        }
    ]

}