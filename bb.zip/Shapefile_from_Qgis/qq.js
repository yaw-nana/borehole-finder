var qq={
    "type": "FeatureCollection",
    "features": [{
        "type": "Feature",
        "properties": {},
        "geometry": {
            "coordinates": [-1.5425329303025421, 6.682785235846538],
            "type": "Point"
        }
    }]
}