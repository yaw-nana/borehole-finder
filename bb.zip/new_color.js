var color = {
    "type": "FeatureCollection",
    "features": [{
        "type": "Feature",
        "properties": {},
        "geometry": {
            "coordinates": [-1.6396312333444882, 6.3235850289299975],
            "type": "Point"
        }
    }, {
        "type": "Feature",
        "properties": {
            "color": "central"
        },
        "geometry": {
            "coordinates": [
                [
                    [-1.5659607513437948, 6.669615937730185],
                    [-1.5662298614320207, 6.669559335382232],
                    [-1.5661675967445774, 6.669294142810799],
                    [-1.5658942653234362, 6.6693528415735415],
                    [-1.5659607513437948, 6.669615937730185]
                ]
            ],
            "type": "Polygon"
        },
        "id": 1
    }]
}